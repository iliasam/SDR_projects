#include <stdio.h>
#include <alt_types.h>
#include "system.h"

#ifndef FFT_CONTROL_H_
#define FFT_CONTROL_H_

#define FTT_LENGTH (int)512


void init_capture_sgdma();
void start_fft_capture(void);//rx_buf - pointer to write data


#endif
