
#ifndef MAIN_H_
#define MAIN_H_

#include <stdio.h>
#include <stdlib.h>
#include <alt_types.h>

void run_timer(void);
alt_u32 get_timer(void);
void itoa(int n, char s[]);
void reverse(char s[]);
inline int convert_value(alt_u32 value);
void draw_waterfall(void);
void draw_spectrum(void);
int check_mouse_buttons(void);

int check_mouse_pos2(int value,int press_x_pos, int press_y_pos, int butt_state);
void draw_buttons(void);

alt_u32 analyse_power(void);

#endif /* MAIN_H_ */
