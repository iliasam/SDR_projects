#include "./PS2/alt_up_ps2_port.h"
#include "./PS2/ps2_mouse.h"
#include <stdio.h>
#include <stdlib.h>
#include "system.h"
#include "sys/alt_irq.h"
#include "mouse_handler.h"

static void handle_ps2_interrupts(void* context, alt_u32 id);

volatile int edge_capture;

volatile int buttons_state;
volatile int mouse_x_pos;
volatile int mouse_y_pos;
volatile int mouse_screen_y_pos;



void turn_mouse_on(void)
{
	int test2;
	int test3;


	test2 = set_mouse_mode(MOUSE_SET_DEFAULT);
	if (test2 == PS2_SUCCESS)
	{
		printf("MOUSE FOUND\n");

/*
		test3 = set_mouse_mode(MOUSE_SET_SAMPLE_RATE);
		if  (test3 == PS2_SUCCESS)
		{
			test3 = set_mouse_mode(40);
			printf("rate\n");

		}
		*/
		test3 = set_mouse_mode(MOUSE_SET_RESOLUTION);
		if  (test3 == PS2_SUCCESS)
		{
			test3 = set_mouse_mode(3);
			printf("resolution\n");

		}

		set_mouse_mode(MOUSE_ENABLE_DATA_REPORTING);


		write_ctrl_reg(ALT_UP_PS2_PORT_CONTROL_RE_MSK);//enable interrupts
		interrupt_init();
	}
	else printf("MOUSE FAIL2!!!\n");

}

void interrupt_init()
{
	clear_FIFO();
	//enable the interrupt enable register inside NIOS II
	NIOS2_WRITE_IENABLE(1<<PS2_CLASSIC_0_IRQ);
	NIOS2_WRITE_STATUS(1); // enable Nios II interrupts

	void* edge_capture_ptr = (void*) &edge_capture;
	alt_irq_register(PS2_CLASSIC_0_IRQ,edge_capture_ptr,handle_ps2_interrupts);
}

static void handle_ps2_interrupts(void* context, alt_u32 id)
{
	int ipending;
	int pos = 0;//����� ��������������� �����

	alt_u8 byte1,byte2,byte3;

	NIOS2_READ_IPENDING(ipending);
	alt_u32 data_reg = 0;
	alt_u16 num = 0;

	if ((ipending & ((int)(1<<PS2_CLASSIC_0_IRQ))) != 0)
	{
		do {
			data_reg = read_data_reg();
			num = read_num_bytes_available(data_reg);

			if (pos>2){pos = 0;}
			switch (pos)
			{
				case 0: {
					byte1 = (alt_u8)(data_reg & 0xff);
					if (((byte1 & (1<<3)) == 0) || ((byte1 & (1<<2)) != 0))
					{
						//wrong position
						pos = 5;
					}
					break;
				}
				case 1: {byte2 = (alt_u8)(data_reg & 0xff);break;}
				case 2:
				{
					byte3 = (alt_u8)(data_reg & 0xff);
					process_mouse_data(byte1, byte2, byte3);
					break;
				}
				default: break;

			}
			pos++;
			//if ((pos - 1) == 0) printf("num %d, data %d, pos=%d\n",num,(alt_u8)(data_reg & 0xff),(pos-1));
			//if ((pos - 1) == 2) printf("x %d, y %d\n",mouse_x_pos,mouse_y_pos);
		} while (num > 1);//� ����������� ������ ��������� ���������� ����

		pos = 0;
		//printf("butt %d\n",byte1);
		clear_FIFO();

	}

}

void process_mouse_data(alt_u8 byte1, alt_u8 byte2, alt_u8 byte3)
{
	alt_16 x_move = 0;
	alt_16 y_move = 0;
	buttons_state = (int)(byte1 & 3);

	if ((byte1 & (1<<4)) == 0)
	{
		//positive
		x_move = (alt_16)byte2;
	}
	else
	{
		//negative
		x_move = 0xff00 | (alt_16)byte2;
	}

	if ((byte1 & (1<<5)) == 0){y_move = (alt_16)byte3;} else {y_move = 0xff00 | (alt_16)byte3;}

	mouse_x_pos+= (int)x_move;
	mouse_y_pos+= (int)y_move;
	if (mouse_x_pos < 0) {mouse_x_pos = 0;}
	if (mouse_x_pos > 639) {mouse_x_pos = 639;}

	if (mouse_y_pos < 0) {mouse_y_pos = 0;}
	if (mouse_y_pos > 479) {mouse_y_pos = 479;}

	mouse_screen_y_pos = 479 - mouse_y_pos;

}


//������������� ������� ���� �� �����
//length - ����� ��������
//butt_state -  ��������� ������ ����
int check_mouse_pos(int value,int max,int min, char length, int x_start, int y_start, int press_x_pos, int press_y_pos, int butt_state)
{
	int char_height = 11*2;
	int char_width = 8*2;

	int string_length = char_width*length;

	char char_pos = 0;

	int delta = 1;
	int return_val = (int)value;

	char i;

	//�������� ��������� � �����
	if ((press_y_pos > y_start) && (press_y_pos < (y_start + char_height)))
	{
		if ((press_x_pos > x_start) && (press_x_pos < (x_start + string_length)))
		{
			char_pos = (alt_u8)((press_x_pos- x_start-2)/char_width);
			char_pos = length-char_pos-1;

			for (i=0;i<char_pos;i++){delta= delta*10;}
			if (butt_state == 2)
			{
				delta = 0-delta;
			}

			return_val = value + delta;
			if (return_val < min) return_val = min;
			if (return_val > max) return_val = max;

			//printf("pos %d, delta %d\n",char_pos,delta);

		}
	}

	return (alt_u32)return_val;
}

//������������� ������� ���� ������
int check_mouse_pos3(int x_start, int y_start,int press_x_pos, int press_y_pos, int butt_state)
{
	int button_height = 40;
	int button_width = 70;

	if ((press_y_pos > y_start) && (press_y_pos < (y_start + button_height)))
	{
		if ((press_x_pos > x_start) && (press_x_pos < (press_x_pos + button_width)))
		{
			return 1;
		}
		else return 0;

	}
	return 0;

}



