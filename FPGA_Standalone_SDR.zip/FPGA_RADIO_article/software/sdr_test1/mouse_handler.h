
#ifndef MOUSE_HANDLER_H_
#define MOUSE_HANDLER_H_

void turn_mouse_on(void);
void process_mouse_data(alt_u8 byte1, alt_u8 byte2, alt_u8 byte3);

void interrupt_init();
void interrupt_handler(void);
int check_mouse_pos(int value,int max,int min, char length, int x_start, int y_start, int press_x_pos, int press_y_pos, int butt_state);
int check_mouse_pos3(int x_start, int y_start,int press_x_pos, int press_y_pos, int butt_state);


#endif /* MOUSE_HANDLER_H_ */
